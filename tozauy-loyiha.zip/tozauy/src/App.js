import { useState, useEffect } from "react";
import {
  collection, addDoc, onSnapshot,
  doc, updateDoc, query, orderBy, serverTimestamp
} from "firebase/firestore";
import { db } from "./firebase";
import "./App.css";

// ─── XIZMATLAR ───────────────────────────────────────────────────────────────
const SERVICES = [
  {
    id: "s1", emoji: "🏠", color: "#34d399",
    title: "Umumiy tozalash",
    desc: "Xonalar, pollar, changyutgich, sirtlar artiladi",
    details: ["Barcha xonalar supuriladi", "Pollar yuvilib artiladi", "Sirtlar changdan tozalanadi", "Oshxona va hammom yuvilib artiladi"],
    duration: "2–3 soat", price: 150000, priceLabel: "150 000 so'm",
  },
  {
    id: "s2", emoji: "✨", color: "#60a5fa",
    title: "Chuqur tozalash",
    desc: "To'la bosh-oyoq: shkaflar ichidan, mebel ostidan",
    details: ["Shkaf va javonlar ichidan tozalanadi", "Mebel ostidan yig'iladi", "Deraza romlar artiladi", "Plita va muzlatgich tozalanadi"],
    duration: "4–6 soat", price: 350000, priceLabel: "350 000 so'm",
  },
  {
    id: "s3", emoji: "🪟", color: "#a78bfa",
    title: "Oyna tozalash",
    desc: "Barcha oynalar ikki tomondan yaltiratiladi",
    details: ["Oynalar ikki tomondan artiladi", "Romlar tozalanadi", "Pardalar silkintiriladi", "Balkon oynalari ham kiritiladi"],
    duration: "1–2 soat", price: 80000, priceLabel: "80 000 so'm",
  },
  {
    id: "s4", emoji: "🛁", color: "#fb923c",
    title: "Hammom tozalash",
    desc: "Hammom va tuvalet to'liq dezinfeksiya qilinadi",
    details: ["Vanna / dush kabinasi dezinfeksiya", "Unitaz va umivaltnik artiladi", "Plitkalar yuvib tozalanadi", "Kran va oynachalar jilolash"],
    duration: "1–2 soat", price: 100000, priceLabel: "100 000 so'm",
  },
  {
    id: "s5", emoji: "🛋️", color: "#f472b6",
    title: "Mebel tozalash",
    desc: "Divan, kreslolar, gilamlar chuqur changyutiladi",
    details: ["Mebel qoplami changyutiladi", "Dog'lar olib tashlanadi", "Gilamlar tozalanadi", "Yostiq va ko'rpa silkintiriladi"],
    duration: "2–3 soat", price: 200000, priceLabel: "200 000 so'm",
  },
  {
    id: "s6", emoji: "🏗️", color: "#fbbf24",
    title: "Ta'mirdan keyin",
    desc: "Qurilish changi, bo'yoq va qoldiqlari olib tashlanadi",
    details: ["Qurilish changi to'liq yig'iladi", "Bo'yoq izlari tozalanadi", "Barcha sirtlar artiladi", "Oynalar va plitalar poklangan"],
    duration: "6–8 soat", price: 600000, priceLabel: "600 000 so'm",
  },
];

const WORKERS = [
  { id: "sarvar", name: "Sarvar", emoji: "👨‍🔧" },
  { id: "dilnoza", name: "Dilnoza", emoji: "👩‍🔧" },
  { id: "bobur", name: "Bobur", emoji: "👨‍🔧" },
];

// ─── APP ─────────────────────────────────────────────────────────────────────
export default function App() {
  const [role, setRole] = useState(null);       // "client" | "worker"
  const [worker, setWorker] = useState(null);   // selected worker
  const [page, setPage] = useState("catalog");
  const [orders, setOrders] = useState([]);
  const [toast, setToast] = useState(null);
  const [selected, setSelected] = useState(null);
  const [form, setForm] = useState({ name: "", address: "", phone: "", note: "" });
  const [sending, setSending] = useState(false);
  const [tab, setTab] = useState("yangi");
  const [expanded, setExpanded] = useState(null);

  // ── Firebase real-time listener ──
  useEffect(() => {
    const q = query(collection(db, "orders"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setOrders(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    });
    return () => unsub();
  }, []);

  function showToast(msg) {
    setToast(msg);
    setTimeout(() => setToast(null), 2800);
  }

  // ── Mijoz: buyurtma berish ──
  async function placeOrder() {
    if (!form.address.trim() || !selected) return;
    setSending(true);
    try {
      await addDoc(collection(db, "orders"), {
        serviceId: selected.id,
        serviceTitle: selected.title,
        serviceEmoji: selected.emoji,
        price: selected.price,
        priceLabel: selected.priceLabel,
        duration: selected.duration,
        clientName: form.name || "Noma'lum",
        address: form.address,
        phone: form.phone,
        note: form.note,
        status: "new",
        workerName: null,
        createdAt: serverTimestamp(),
      });
      setForm({ name: "", address: "", phone: "", note: "" });
      setSelected(null);
      setPage("myorders");
      showToast("✅ Buyurtma yuborildi!");
    } catch (e) {
      showToast("❌ Xatolik: " + e.message);
    }
    setSending(false);
  }

  // ── Ishlovchi: holat o'zgartirish ──
  async function updateStatus(orderId, status) {
    try {
      await updateDoc(doc(db, "orders", orderId), {
        status,
        workerName: status === "accepted" || status === "done" ? worker.name : null,
      });
      if (status === "accepted") showToast("✅ Buyurtma qabul qilindi!");
      if (status === "rejected") showToast("❌ Rad etildi");
      if (status === "done") showToast("🎉 Bajarildi!");
    } catch (e) {
      showToast("❌ Xatolik: " + e.message);
    }
  }

  const newCount = orders.filter(o => o.status === "new").length;
  const filteredOrders =
    tab === "yangi" ? orders.filter(o => o.status === "new") :
    tab === "qabul" ? orders.filter(o => o.status === "accepted") :
    orders.filter(o => o.status === "done" || o.status === "rejected");

  // ── SAHIFALAR ──────────────────────────────────────────────────────────────

  if (!role) return (
    <div className="app">
      <div className="role-screen">
        <div className="logo">TozaUy 🧹</div>
        <p className="role-sub">Siz kimligingizni tanlang</p>
        <div className="role-card" onClick={() => { setRole("client"); setPage("catalog"); }}>
          <div className="role-emoji">🏠</div>
          <div className="role-card-title">Mijoz</div>
          <div className="role-card-desc">Xizmatlarni ko'rib, buyurtma beraman</div>
        </div>
        <div className="role-card" onClick={() => setRole("worker-select")}>
          <div className="role-emoji">🧹</div>
          <div className="role-card-title">Ishlovchi</div>
          <div className="role-card-desc">Buyurtmalarni qabul qilib, bajaraman</div>
        </div>
      </div>
    </div>
  );

  if (role === "worker-select") return (
    <div className="app">
      <div className="role-screen">
        <div className="logo">👷 Kim siz?</div>
        <p className="role-sub">Profilingizni tanlang</p>
        {WORKERS.map(w => (
          <div className="role-card ws-card" key={w.id}
            onClick={() => { setWorker(w); setRole("worker"); setPage("orders"); setTab("yangi"); }}>
            <span style={{ fontSize: 32 }}>{w.emoji}</span>
            <div>
              <div className="role-card-title">{w.name}</div>
              <div className="role-card-desc">Tozalovchi xodim</div>
            </div>
          </div>
        ))}
        <button className="back-btn" onClick={() => setRole(null)}>← Orqaga</button>
      </div>
    </div>
  );

  return (
    <div className="app">
      {toast && <div className="toast">{toast}</div>}

      {/* HEADER */}
      <div className="header">
        <div className="logo-sm">TozaUy 🧹</div>
        <button className="role-badge" onClick={() => { setRole(null); setWorker(null); }}>
          {role === "client" ? "👤 Mijoz" : `${worker.emoji} ${worker.name}`} ↩
        </button>
      </div>

      {/* ── MIJOZ ── */}
      {role === "client" && (
        <div className="content">
          {/* Katalog */}
          {page === "catalog" && (
            <>
              <div className="sect-title">Xizmatlarimiz</div>
              {SERVICES.map(svc => (
                <div key={svc.id} className="svc-card"
                  style={{ borderTopColor: expanded === svc.id ? svc.color : "transparent" }}>
                  <div className="svc-top" onClick={() => setExpanded(expanded === svc.id ? null : svc.id)}>
                    <span className="svc-emoji">{svc.emoji}</span>
                    <div className="svc-info">
                      <div className="svc-title">{svc.title}</div>
                      <div className="svc-desc">{svc.desc}</div>
                    </div>
                  </div>
                  {expanded === svc.id && (
                    <ul className="detail-list">
                      {svc.details.map((d, i) => (
                        <li key={i} style={{ color: svc.color }}>
                          <span style={{ color: "#eef0f6" }}>{d}</span>
                        </li>
                      ))}
                    </ul>
                  )}
                  <div className="svc-footer">
                    <div>
                      <div className="svc-price" style={{ color: svc.color }}>{svc.priceLabel}</div>
                      <div className="svc-dur">⏱ {svc.duration}</div>
                    </div>
                    <button className="order-btn"
                      style={{ background: svc.color + "22", color: svc.color, border: `1px solid ${svc.color}55` }}
                      onClick={() => { setSelected(svc); setPage("order"); }}>
                      Buyurtma →
                    </button>
                  </div>
                </div>
              ))}
            </>
          )}

          {/* Buyurtma formi */}
          {page === "order" && selected && (
            <>
              <div className="summary-box" style={{ borderColor: selected.color + "44" }}>
                <span style={{ fontSize: 36 }}>{selected.emoji}</span>
                <div>
                  <div style={{ fontWeight: 700, color: selected.color, marginBottom: 2 }}>{selected.title}</div>
                  <div className="svc-dur">{selected.priceLabel} · ⏱ {selected.duration}</div>
                </div>
              </div>
              <div className="form-surface">
                <div className="form-title">📋 Buyurtma ma'lumotlari</div>
                <label className="lbl">Ismingiz</label>
                <input className="inp" placeholder="Aziza Karimova"
                  value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
                <label className="lbl">Manzil *</label>
                <input className="inp" placeholder="Ko'cha, uy, xonadon raqami"
                  value={form.address} onChange={e => setForm({ ...form, address: e.target.value })} />
                <label className="lbl">Telefon</label>
                <input className="inp" placeholder="+998 90 123 45 67" type="tel"
                  value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} />
                <label className="lbl">Izoh (ixtiyoriy)</label>
                <textarea className="inp" rows={3} placeholder="Qavat, kirish kodi, vaqt..."
                  value={form.note} onChange={e => setForm({ ...form, note: e.target.value })} />
                <button className="btn-main" disabled={!form.address.trim() || sending} onClick={placeOrder}>
                  {sending ? "Yuborilmoqda..." : "✅ Buyurtma berish"}
                </button>
                <button className="back-btn" onClick={() => setPage("catalog")}>← Orqaga</button>
              </div>
            </>
          )}

          {/* Mening buyurtmalarim */}
          {page === "myorders" && (
            <>
              <div className="sect-title">Mening buyurtmalarim</div>
              {orders.length === 0 ? (
                <div className="empty">
                  <div style={{ fontSize: 48 }}>📭</div>
                  <p>Hozircha buyurtma yo'q.<br />Xizmat tanlang va buyurtma bering!</p>
                </div>
              ) : orders.map(o => (
                <div key={o.id} className="order-card">
                  <div className="order-top">
                    <div>
                      <div className="order-title">{o.serviceEmoji} {o.serviceTitle}</div>
                      <div className="order-meta">{o.address}</div>
                      {o.phone && <div className="order-meta">📞 {o.phone}</div>}
                      {o.note && <div className="order-meta italic">💬 {o.note}</div>}
                      {o.workerName && <div className="order-meta">🧹 {o.workerName}</div>}
                    </div>
                    <span className={`badge badge-${o.status}`}>
                      {o.status === "new" ? "⏳ Kutish"
                        : o.status === "accepted" ? "✅ Qabul"
                        : o.status === "done" ? "🎉 Bajarildi"
                        : "❌ Rad"}
                    </span>
                  </div>
                  <div className="order-footer">
                    <span className="price-text">{o.priceLabel}</span>
                    <span className="svc-dur">⏱ {o.duration}</span>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>
      )}

      {/* ── ISHLOVCHI ── */}
      {role === "worker" && (
        <div className="content">
          <div className="tabs">
            <button className={`tab ${tab === "yangi" ? "active" : ""}`} onClick={() => setTab("yangi")}>
              🔔 Yangi {newCount > 0 && <span className="cnt">{newCount}</span>}
            </button>
            <button className={`tab ${tab === "qabul" ? "active" : ""}`} onClick={() => setTab("qabul")}>✅ Qabul</button>
            <button className={`tab ${tab === "tarix" ? "active" : ""}`} onClick={() => setTab("tarix")}>📋 Tarix</button>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="empty">
              <div style={{ fontSize: 48 }}>📭</div>
              <p>{tab === "yangi" ? "Yangi buyurtmalar yo'q.\nMijoz buyurtma berganda shu yerda ko'rinadi." : "Hozircha bo'sh."}</p>
            </div>
          ) : filteredOrders.map(o => (
            <div key={o.id} className={`order-card ${o.status === "new" ? "pulse-card" : ""}`}>
              <div className="order-top">
                <div>
                  <div className="order-title">{o.serviceEmoji} {o.serviceTitle}</div>
                  <div className="order-meta">👤 {o.clientName}</div>
                  <div className="order-meta">📍 {o.address}</div>
                  {o.phone && <div className="order-meta">📞 {o.phone}</div>}
                  {o.note && <div className="order-meta italic">💬 {o.note}</div>}
                </div>
                <span className={`badge badge-${o.status}`}>
                  {o.status === "new" ? "🔔 Yangi"
                    : o.status === "accepted" ? "✅ Qabul"
                    : o.status === "done" ? "🎉 Bajarildi"
                    : "❌ Rad"}
                </span>
              </div>
              <div className="order-footer">
                <span className="price-text">{o.priceLabel}</span>
                <span className="svc-dur">⏱ {o.duration}</span>
              </div>
              {o.status === "new" && (
                <div className="action-row">
                  <button className="btn-accept" onClick={() => updateStatus(o.id, "accepted")}>✅ Qabul</button>
                  <button className="btn-reject" onClick={() => updateStatus(o.id, "rejected")}>❌ Rad</button>
                </div>
              )}
              {o.status === "accepted" && (
                <button className="btn-done" onClick={() => updateStatus(o.id, "done")}>🎉 Bajarildi deb belgilash</button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* NAV */}
      <nav className="nav">
        {role === "client" ? (
          <>
            <button className={`nav-btn ${page === "catalog" ? "active" : ""}`} onClick={() => setPage("catalog")}>
              <span>🏠</span><span className="nav-lbl">Xizmatlar</span>
            </button>
            <button className={`nav-btn ${page === "myorders" ? "active" : ""}`} onClick={() => setPage("myorders")}>
              <span className="rel">📋{orders.filter(o => o.status === "accepted").length > 0 && <span className="red-dot" />}</span>
              <span className="nav-lbl">Buyurtmalarim</span>
            </button>
          </>
        ) : (
          <>
            {["yangi", "qabul", "tarix"].map(t => (
              <button key={t} className={`nav-btn ${tab === t ? "active" : ""}`} onClick={() => setTab(t)}>
                <span className="rel">
                  {t === "yangi" ? "🔔" : t === "qabul" ? "✅" : "📋"}
                  {t === "yangi" && newCount > 0 && <span className="red-dot" />}
                </span>
                <span className="nav-lbl">{t === "yangi" ? "Yangi" : t === "qabul" ? "Qabul" : "Tarix"}</span>
              </button>
            ))}
          </>
        )}
      </nav>
    </div>
  );
}
